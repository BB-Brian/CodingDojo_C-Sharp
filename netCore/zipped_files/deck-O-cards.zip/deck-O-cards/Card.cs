namespace deck_O_cards
{
    public class Card
    {
        string stringval;
        string suit;
        int val;

        public Card(string stringval, string suit, int val)
        {
            this.stringval = stringval; //same as _stringval, stringval, StringValue
            this.suit = suit;
            this.val = val;
        }   
    }  
}

