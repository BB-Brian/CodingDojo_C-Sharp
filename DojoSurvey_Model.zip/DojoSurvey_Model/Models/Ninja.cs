using System;

namespace DojoSurvey_Model.Models
{
    public class Ninja 
    {
        public string name{get; set;}
        public string language{get; set;}
        public string location{get; set;}
        public string comment{get; set;}
    }
}