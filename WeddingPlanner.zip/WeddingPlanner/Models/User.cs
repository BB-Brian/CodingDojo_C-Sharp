
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WeddingPlanner.Models
    {
    public class User
    {
        [Key]
        public int UserId {get;set;}
        [Required]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "First Name can only contain letters")]
        [MinLength(2, ErrorMessage= "First Name must have at least 2 letters")]
        public string FirstName {get;set;}
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Last Name can only contain letters")]
        [Required]
        [MinLength(2, ErrorMessage= "Last Name must have at least 2 letters")]
        public string LastName {get;set;}
        [Required]
        [RegularExpression(@"^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$", ErrorMessage = "Invalid email format.")]
        public string Email {get;set;}
        [Required]
        [MinLength(8, ErrorMessage= "Password must have at least 8 characters.")]
        public string Password {get;set;}
        // [NotMapped]
        // [Required]
        // [Compare(nameof(Password),ErrorMessage="Passwords do not match.")]
        // public string PasswordConfirm {get;set;}

        [Timestamp]
        public DateTime createdAt{get;set;}
        [Timestamp]
        public DateTime updatedAt{get;set;}
        // public List<Guest> GuestList { get;set; }
        // public List<Wedding> WeddingsICreated { get;set; }
        // public List<Wedding> WeddingsCreated {get;set;}
        public List<Rsvp> WeddingsIAmAttending {get;set;}
        public List<Wedding> WeddingsICreated {get;set;}


        public User(){
            // WeddingsICreated = new List<Wedding>();
            WeddingsIAmAttending = new List<Rsvp>();
            WeddingsICreated = new List<Wedding>();
        }
    }
}