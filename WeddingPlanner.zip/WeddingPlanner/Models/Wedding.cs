using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace WeddingPlanner.Models
{    
    public class Wedding
    {
        [Key]
        public int WeddingId {get;set;}
        [Required]
        public string Wedder1 {get;set;}
        [Required]
        public string Wedder2 {get;set;}
        [Required]
        [FutureDate(ErrorMessage = "Wedding must be in the future!")]  //see FutureDateAttribute defined below
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:MM-dd-yyyy}")]
        public DateTime Date {get;set;}
        [Required]
        public string Address {get;set;}
        public int UserId {get; set;}
        public User User {get; set;}
        public List<Rsvp> GuestList {get; set;}
        public Wedding(){
            GuestList = new List<Rsvp>();
        }
        public class FutureDateAttribute : ValidationAttribute
        {
            public FutureDateAttribute() { }
            public override bool IsValid(object value)
            {
                var date = (DateTime)value;
                if (date > DateTime.Now)
                {
                    return true;
                }
                return false;
            }
        }
    }
}