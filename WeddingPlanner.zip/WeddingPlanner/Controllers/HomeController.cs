﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WeddingPlanner.Models;

namespace WeddingPlanner.Controllers
{
    public class HomeController : Controller
    {
        private WeddingContext _context;
        public HomeController(WeddingContext context){
            _context = context;
        }
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost("Register")]
        public IActionResult Register(User user, string PasswordConfirm){
            User userEmail = _context.Users.SingleOrDefault(login => login.Email == user.Email);
            if(user.Password == PasswordConfirm){
                if(userEmail == null){
                    if(ModelState.IsValid){
                        // user.createdAt = DateTime.Now; CURRENT_TIMESTAMP in MySql
                        // user.updatedAt = DateTime.Now; CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                        PasswordHasher<User> Hasher = new PasswordHasher<User>();
                        user.Password = Hasher.HashPassword(user, user.Password);
                        _context.Add(user);
                        _context.SaveChanges();
                        int? userId = user.UserId;
                        // HttpContext.Session.SetInt32("userId",user.UserId);
                        HttpContext.Session.SetInt32("userId",(int)userId);
                        Console.WriteLine(userId + " registration Success!");
                        return RedirectToAction("Dashboard");
                    }
                    else{
                        return View("Index");
                    }
                }
                else{
                    ViewBag.Error = "Email already registered.";
                    return View("Index");
                }
            }
            else{
                ViewBag.PasswordConfirmError = "Passwords do not match.";
                return View("Index");
            }
        }
        [HttpPost("Login")]
        // [Route("")]
        public IActionResult Login(string Email, string Password)
        {
            if(Email==null || Password==null){
                ViewBag.Error = "Cannot leave field(s) blank.";
                return View("Index");
            }
            else{
                User user = _context.Users.SingleOrDefault(data => data.Email == Email);
                if(user != null){
                    var Hasher = new PasswordHasher<User>();
                    if(0 != Hasher.VerifyHashedPassword(user, user.Password, Password)){ 
                        // int? userId = user.UserId; 
                        HttpContext.Session.SetInt32("userId",user.UserId); /////////////////SUCCESS
                        Console.WriteLine(user.UserId + " login success ***************");
                        return RedirectToAction("Dashboard");
                    }
                    else{
                        ViewBag.Error = "Invalid login."; /////invalid entries
                        return View("Index");
                    }
                }
                else{
                    ViewBag.Error = "Email not registered."; /////email not registered
                    return View("Index");
                }
            }
        }
        [HttpGet, Route("Dashboard")]
        public IActionResult Dashboard()
        {
            if(HttpContext.Session.GetInt32("userId") == null) {
                return RedirectToAction("Index");
            }
            else{
                int? userId = HttpContext.Session.GetInt32("userId");
                Console.WriteLine(userId);
                Console.WriteLine(" *********made it to Dashboard");
                List<Wedding> allWeddings = _context.Weddings.Include(w => w.GuestList).ThenInclude(g => g.User).ToList();
                User curUser = _context.Users.SingleOrDefault(data => data.UserId == (int)userId);
                ViewBag.weddings = allWeddings;    
                ViewBag.userId = curUser.UserId;
                ViewBag.firstName = curUser.FirstName;
                return View("Dashboard");
            }
        }
        [HttpGet]
        [Route("wedding")]
        public IActionResult AddWedding(){
            return View("Wedding");
        }
        [HttpPost]
        [Route("wedding")]
        public IActionResult PostAddWedding(Wedding weddingForm){
            
            if(ModelState.IsValid){
                int? userId = HttpContext.Session.GetInt32("userId");
                weddingForm.UserId = (int)userId;
                _context.Weddings.Add(weddingForm);
                _context.SaveChanges();

                return RedirectToAction("Details", new { WeddingId = weddingForm.WeddingId});
            }
            else{
                return View("Wedding");
            }
        }
        [HttpGet]
        [Route("wedding/{WeddingId}")]
        public IActionResult Details(int WeddingId){
            Wedding thisWedding = _context.Weddings.Include(data => data.GuestList).ThenInclude(data => data.User).SingleOrDefault(data => data.WeddingId == WeddingId);
            ViewBag.wedding = thisWedding;
            return View();
        }
        [HttpGet, Route("/wedding/{WeddingId}/delete")]
        public IActionResult DeleteWedding(int WeddingId)
        {
            Wedding wedding = _context.Weddings.SingleOrDefault(w => w.WeddingId == WeddingId);
            _context.Weddings.Remove(wedding);
            _context.SaveChanges();
            return RedirectToAction("Dashboard");
        }
// ########################################################################################################
        [HttpGet]
        [Route("/wedding/{WeddingId}/Rsvp")]
        public IActionResult Attend(int WeddingId){
            int? UserId = HttpContext.Session.GetInt32("userId");
            Rsvp newRsvp = new Rsvp{
                UserId = (int)UserId,
                WeddingId = WeddingId,
            };
            _context.Rsvps.Add(newRsvp);
            _context.SaveChanges();
            return RedirectToAction("Dashboard");
        }
        [HttpGet]
        [Route("/wedding/{WeddingId}/UnRsvp")]
        public IActionResult Unattend(int WeddingId){
            int? UserId = HttpContext.Session.GetInt32("userId");
            Rsvp RsvpToUnRsvp = _context.Rsvps.SingleOrDefault(data => data.UserId == (int)UserId && data.WeddingId == WeddingId);
            _context.Rsvps.Remove(RsvpToUnRsvp);
            _context.SaveChanges();
            return RedirectToAction("Dashboard");
        }
// ########################################################################################################
        [HttpGet]
        [Route("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return Redirect("/");
        }
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
