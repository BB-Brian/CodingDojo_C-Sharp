using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace planner
{
    public class Act
    {
        [Key]

        public int ActivityId { get; set; }

        [Required]
        [MinLength(2)]
        public string Title { get; set; }
        public int CoordinatorId { get; set; }

        public User Coordinator {get; set;}

        [Required]
        public DateTime DateTime { get; set; }

        [Required]
        
        public int DurationLength { get; set; }
        [Required]
        public string DurationType { get; set; }
        [Required]

        public string Description { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        public List<Participant> participants {get; set;}

        public Act()
        {
            participants = new List<Participant>();
        }
    }
}