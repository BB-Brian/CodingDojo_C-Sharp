using System;

namespace planner
{
    public class Participant
    {
        public int ParticipantId {get; set;}
        
        public int UserId {get; set;}

        public int ActivityId {get; set;}

        public DateTime CreatedAt {get; set;}

        public DateTime UpdatedAt {get; set;}
    }
}