﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using LoginRegDemo.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;

namespace LoginRegDemo.Controllers {
    public class HomeController : Controller {

        private UserContext _context;

        public HomeController (UserContext context) {
            _context = context;
        }

        public IActionResult Index () {
            return View ();
        }

        [HttpPost]
        [Route ("RegisterUser")]
        public IActionResult RegisterUser (User MyUser, string ConfirmPassword) {
            //check if ModelState is valid
            //check if passwords match
            //add to db and save
            //Go to success page
            //else, don't add and create your own error
            //else render index page....don't redirect!
            System.Console.WriteLine ("WE HIT REGISTERED USER FUNCTION IN CONTROLLER");

            if (ModelState.IsValid) {
                PasswordHasher<User> Hasher = new PasswordHasher<User>();
                MyUser.Password = Hasher.HashPassword(MyUser, MyUser.Password);
                User ExistingUser = _context.users.SingleOrDefault (u => u.Email == MyUser.Email);
                if (ExistingUser != null) {
                    System.Console.WriteLine (" *************EMAIL ALREADY IN USE**********************");
                    ViewBag.AlreadyInUseEmail = true;
                    // ViewBag.AlreadyInUseEmail = $"{MyUser.Email} is already in the Data base, YOU FUCK!";
                    return View ("Index");
                    // Yo dude Have you ever watched Mike Tyson Mysteries? Its really good show.
                }
                _context.Add (MyUser);
                _context.SaveChanges ();

                // grabs all reviews from database

                return RedirectToAction ("Success");
            } else {
                System.Console.WriteLine ("There were errors adding user returned to index********************");
                return View ("Index");
            }

        }
        public IActionResult Success () {
            List<User> AllUsers = _context.users.ToList ();
            ViewBag.AllUsers = AllUsers;
            return View ();
        }

        [HttpPost]
        [Route ("LoginUser")]
        public IActionResult LoginUser (string Email, string Password) {
            //is user in database???? Use where or Singleordefault or firstordefault
            //check queried user's password against our passed in password

            //go to success(maybe add stuff to session first?)
            //otherwise, get some error messages to our user
            return RedirectToAction ("Index");
        }

        // public IActionResult About()
        // {
        //     ViewData["Message"] = "Your application description page.";

        //     return View();
        // }

        // public IActionResult Contact()
        // {
        //     ViewData["Message"] = "Your contact page.";

        //     return View();
        // }

        public IActionResult Error () {
            return View (new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}